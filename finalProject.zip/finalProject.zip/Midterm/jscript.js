function setCity(obj) {
  var chipDiv, objFact, objPic;
  let id = obj.selectedIndex;
  switch (id) {
    case 0:
      city = "Dutch Harbor";
      break;
    case 1:
      city = "Tempe";
      break;
    case 2:
      city = "Copenhagen";
      break;
    case 3:
      city = "Laguna Beach";
      break;
    default:
      city = "Seattle";
      break;
  }

  //   for (var x = 0; x < 5, x++) {
  //     objFact = document.getElementById('${x}fact');
  //     objFact.style.display = 'none';

  //     objPic =  document.getElementById('${x}pic');
  //     objPic.style.display = 'none';
  //   }
}
