function setCity(id) {
  var objFact, objPic;

  switch (id) {
    case 1:
      city = "Tempe";
      break;
    case 2:
      city = "Copenhagen";
      break;
    case 3:
      city = "Dana Point";
      break;
    case 4:
      city = "Dutch Harbor";
      break;
    default:
      city = "Seattle";
      break;
  }
}
